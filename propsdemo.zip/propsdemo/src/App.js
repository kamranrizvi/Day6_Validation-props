import './App.css';

import PersonDefaultDemo from './Components/DefaultProp'

import ArrayProps from './Components/ArrayAsProps'


// import ParentSampleRenderProps from './Components/RenderPropDemo'

import GrandParent from './Components/DefaultProp';

function App() {
  return (
    // Default Prop - Class Componet with Props
    <div >
       <PersonDefaultDemo></PersonDefaultDemo>
       <PersonDefaultDemo name="Kamran Saiyed" gender="Male"></PersonDefaultDemo>
       <PersonDefaultDemo name="Swati Solanki" gender="Female"></PersonDefaultDemo>
       <PersonDefaultDemo name="Nidhi Chhangani" gender="Female"></PersonDefaultDemo>
     </div>

    // Array as Props
    // <ArrayProps></ArrayProps>


    // Render Props
    // <ParentSampleRenderProps/>
    
  );
}

export default App;
